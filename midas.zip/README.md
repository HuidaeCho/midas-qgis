# Memory-Efficient I/O-Improved Drainage Analysis System (MIDAS) QGIS Plugin

The [MIDAS](https://github.com/HuidaeCho/midas) [QGIS](https://qgis.org/) plugin offers memory-efficient, OpenMP-parallelized algorithms for computing hydrologic parameters. [MIDAS](https://github.com/HuidaeCho/midas) executable files need to be installed separately in `PATH`.
